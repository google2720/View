package com.view;

/**
 * Created by zhangjunjun on 2017/5/28.
 */

public enum SEX {
    MAN, WOMAN;
}
