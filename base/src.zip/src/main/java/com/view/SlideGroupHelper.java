package com.view;

import android.util.Log;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.ViewConfiguration;
import android.widget.Scroller;

/**
 * Created by zhangjunjun on 2017/5/28.
 */

public class SlideGroupHelper {


    SlideGroup slideGroup;
    float x,y;
    private Scroller mScroller;
    private VelocityTracker velocityTracker;
    private final int mMaximumFlingVelocity;
    private final int mMinimumFlingVelocity;
    private int mPointerId;
    private int currentPage=0;


    public SlideGroupHelper(SlideGroup slideGroup) {
        this.slideGroup = slideGroup;
        mScroller = new Scroller(slideGroup.getContext());
        this.slideGroup.setDisPathEvent(disPathEvent);
        mMaximumFlingVelocity = ViewConfiguration.get(slideGroup.getContext()).getScaledMaximumFlingVelocity();
        mMinimumFlingVelocity = ViewConfiguration.get(slideGroup.getContext()).getScaledMinimumFlingVelocity();
    }


    private SlideGroup.disPathEvent disPathEvent = new SlideGroup.disPathEvent() {
        @Override
        public void onEvent(MotionEvent event) {
            onTouchEvent(event);
        }

        @Override
        public void computeScroll() {
            if (mScroller.computeScrollOffset()) {
                if (slideGroup.mOrientation == slideGroup.HORIZONTAL) {
                    slideGroup.scrollTo(mScroller.getCurrX(), 0);
                    slideGroup.postInvalidate();
                } else {
                    slideGroup.scrollTo(0, mScroller.getCurrY());
                    slideGroup.postInvalidate();
                }
            }
        }
    };



    private void onTouchEvent(MotionEvent event)
    {
// 1.实现了普通滑动,松手后停止
//        final int action = event.getAction();
//        if (BuildConfig.DEBUG)
//            Log.d("onTouchEvent", "action: " + action);
//        switch (action) {
//            case MotionEvent.ACTION_DOWN:
//                x = event.getX();
//                y = event.getY();
//                break;
//            case MotionEvent.ACTION_MOVE:
//                float mx = event.getX();
//                float my = event.getY();
//
//                //此处的moveBy是根据水平或是垂直排放的方向，
//                //来选择是水平移动还是垂直移动
//                moveBy((int) (x - mx), (int) (y - my));
//
//                x = mx;
//                y = my;
//                break;
//        }

        
//    2.解决多手指跳跃的问题
//     final int action = event.getAction();
//
//        if (BuildConfig.DEBUG)
//            Log.d("onTouchEvent", "action: " + action);
//
//        //将事件加入到VelocityTracker中，用于计算手指抬起时的初速度
//        if (velocityTracker == null) {
//            velocityTracker = VelocityTracker.obtain();
//        }
//        velocityTracker.addMovement(event);
//
//        switch (action) {
//            case MotionEvent.ACTION_DOWN:
//                x = event.getX();
//                y = event.getY();
//                if (!mScroller.isFinished())
//                    mScroller.abortAnimation();
//                break;
//            case MotionEvent.ACTION_MOVE:
//                float mx = event.getX();
//                float my = event.getY();
//
//                moveBy((int) (x - mx), (int) (y - my));
//
//                x = mx;
//                y = my;
//                break;
//            case MotionEvent.ACTION_UP:
//                //maxFlingVelocity是通过ViewConfiguration来获取的初速度的上限
//                //这个值可能会因为屏幕的不同而不同
//                velocityTracker.computeCurrentVelocity(1000, maxFlingVelocity);
//                float velocityX = velocityTracker.getXVelocity();
//                float velocityY = velocityTracker.getYVelocity();
//
//                //用来处理实际的移动
//                completeMove(-velocityX, -velocityY);
//                if (velocityTracker != null) {
//                    velocityTracker.recycle();
//                    velocityTracker = null;
//                }
//                break;
//        }

        final int action = event.getActionMasked();

        if (velocityTracker == null) {
            velocityTracker = VelocityTracker.obtain();
        }
        velocityTracker.addMovement(event);

        switch (action) {
            case MotionEvent.ACTION_DOWN:
                // 获取索引为0的手指id
                mPointerId = event.getPointerId(0);
                x = event.getX();
                y = event.getY();
                if (!mScroller.isFinished())
                    mScroller.abortAnimation();
                break;
            case MotionEvent.ACTION_MOVE:
                // 获取当前手指id所对应的索引，虽然在ACTION_DOWN的时候，我们默认选取索引为0
                // 的手指，但当有第二个手指触摸，并且先前有效的手指up之后，我们会调整有效手指

                // 屏幕上可能有多个手指，我们需要保证使用的是同一个手指的移动轨迹，
                // 因此此处不能使用event.getActionIndex()来获得索引
                final int pointerIndex = event.findPointerIndex(mPointerId);
                float mx = event.getX(pointerIndex);
                float my = event.getY(pointerIndex);

                moveBy((int) (x - mx), (int) (y - my));

                x = mx;
                y = my;
                break;
            case MotionEvent.ACTION_UP:
                velocityTracker.computeCurrentVelocity(1000, mMaximumFlingVelocity);
                float velocityX = velocityTracker.getXVelocity(mPointerId);
                float velocityY = velocityTracker.getYVelocity(mPointerId);

                if ((Math.abs(velocityY) > mMinimumFlingVelocity) || (Math.abs(velocityX) > mMinimumFlingVelocity)){
                    //快划



                }

                completeMove(-velocityX, -velocityY);
                if (velocityTracker != null) {
                    velocityTracker.recycle();
                    velocityTracker = null;
                }
                break;

            case MotionEvent.ACTION_POINTER_UP:
                // 获取离开屏幕的手指的索引
                int pointerIndexLeave = event.getActionIndex();
                int pointerIdLeave = event.getPointerId(pointerIndexLeave);
                if (mPointerId == pointerIdLeave) {
                    // 离开屏幕的正是目前的有效手指，此处需要重新调整，并且需要重置VelocityTracker
                    int reIndex = pointerIndexLeave == 0 ? 1 : 0;
                    mPointerId = event.getPointerId(reIndex);
                    // 调整触摸位置，防止出现跳动
                    x = event.getX(reIndex);
                    y = event.getY(reIndex);
                    if (velocityTracker != null)
                        velocityTracker.clear();
                }
                break;
        }
    }

    //此处的moveBy是根据水平或是垂直排放的方向，
    //来选择是水平移动还是垂直移动
    public void moveBy(int deltaX, int deltaY) {
        if (BuildConfig.DEBUG)
            Log.d("moveBy", "deltaX: " + deltaX + "    deltaY: " + deltaY);
        if (slideGroup.mOrientation == slideGroup.HORIZONTAL) {
            if (Math.abs(deltaX) >= Math.abs(deltaY))
                slideGroup.scrollBy(deltaX, 0);
        } else {
            if (Math.abs(deltaY) >= Math.abs(deltaX))
                slideGroup.scrollBy(0, deltaY);
        }
    }

// 1.没有处理回弹的情况
// private void completeMove(float velocityX, float velocityY) {
//        if (slideGroup.mOrientation == slideGroup.HORIZONTAL) {
//            int mScrollX = slideGroup.getScrollX();
//            int maxX = slideGroup.desireWidth - slideGroup.getWidth();// - Math.abs(mScrollX);
//
//            if (Math.abs(velocityX) >= minFlingVelocity && maxX > 0) {
//
//                mScroller.fling(mScrollX, 0, (int) velocityX, 0, 0, maxX, 0, 0);
//                slideGroup.invalidate();
//            }
//        } else {
//            int mScrollY = slideGroup.getScrollY();
//            int maxY = slideGroup.desireHeight - slideGroup.getHeight();// - Math.abs(mScrollY);
//
//            if (Math.abs(velocityY) >= minFlingVelocity && maxY > 0) {
//
//                mScroller.fling(0, mScrollY, 0, (int) velocityY, 0, 0, 0, maxY);
//                slideGroup.invalidate();
//            }
//        }
//    }

    //2.有处理回弹的情况
    private void completeMove(float velocityX, float velocityY) {
        if (slideGroup.mOrientation == slideGroup.HORIZONTAL) {
            int mScrollX = slideGroup.getScrollX();
            int maxX = slideGroup.desireWidth - slideGroup.getWidth();
            if (mScrollX > maxX) {
                // 超出了右边界，弹回
                mScroller.startScroll(mScrollX, 0, maxX - mScrollX, 0);
                slideGroup.invalidate();
            } else if (mScrollX < 0) {
                // 超出了左边界，弹回
                mScroller.startScroll(mScrollX, 0, -mScrollX, 0);
                slideGroup.invalidate();
            } else if (Math.abs(velocityX) >= mMinimumFlingVelocity && maxX > 0) {
                mScroller.fling(mScrollX, 0, (int) velocityX, 0, 0, maxX, 0, 0);
                slideGroup.invalidate();
            }
        } else {
            int mScrollY = slideGroup.getScrollY();
            int maxY = slideGroup.desireHeight - slideGroup.getHeight();

            if (mScrollY > maxY) {
                // 超出了下边界，弹回
                mScroller.startScroll(0, mScrollY, 0, maxY - mScrollY);
                slideGroup.invalidate();
            } else if (mScrollY < 0) {
                // 超出了上边界，弹回
                mScroller.startScroll(0, mScrollY, 0, -mScrollY);
                slideGroup.invalidate();
            } else if (Math.abs(velocityY) >= mMinimumFlingVelocity && maxY > 0) {
                mScroller.fling(0, mScrollY, 0, (int) velocityY, 0, 0, 0, maxY);
                slideGroup.invalidate();
            }
        }
    }


}
