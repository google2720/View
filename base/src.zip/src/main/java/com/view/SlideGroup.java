package com.view;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;

/**
 * Created by zhangjunjun on 2017/5/28.
 */

public class SlideGroup extends ViewGroup {

    public int desireWidth;
    public int desireHeight;
    public int mOrientation;
    public static final int HORIZONTAL = -1;
    public static final int VERTICAL = 0;
    private disPathEvent disPathEvent;

    public SlideGroup(Context context) {
        this(context, null);
    }

    public SlideGroup(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }


    public SlideGroup(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);

    }




    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {

        desireWidth = 0;
        desireHeight = 0;
        int count = getChildCount();
        for (int i = 0; i < count; ++i) {
            View v = getChildAt(i);
            if (v.getVisibility() != View.GONE) {
// 1.最基本的
//                measureChild(v, widthMeasureSpec, heightMeasureSpec);
//                // 计算所有child view 要占用的空间
//                desireWidth += v.getMeasuredWidth();
//                // 选取子View中高度最高的一个作为viewGroup的高度
//                desireHeight = Math.max(desireHeight, v.getMeasuredHeight());

// 2.增加Margin的支持
//                LayoutParams lp = (LayoutParams) v.getLayoutParams();
//                //将measureChild改为measureChildWithMargin
//                measureChildWithMargins(v, widthMeasureSpec, 0,
//                        heightMeasureSpec, 0);
//                //这里在计算宽度时加上margin
//                desireWidth += v.getMeasuredWidth() + lp.leftMargin + lp.rightMargin;
//                desireHeight = Math
//                        .max(desireHeight, v.getMeasuredHeight() + lp.topMargin + lp.bottomMargin);

                LayoutParams lp = (LayoutParams) v.getLayoutParams();
                measureChildWithMargins(v, widthMeasureSpec, 0,
                        heightMeasureSpec, 0);

                int orientation = lp.orientation;
                mOrientation = orientation;
                //3.只是在这里增加了垂直或者水平方向的判断
                if (orientation == HORIZONTAL) {
                    desireWidth += v.getMeasuredWidth() + lp.leftMargin
                            + lp.rightMargin;
                    desireHeight = Math.max(desireHeight, v.getMeasuredHeight()
                            + lp.topMargin + lp.bottomMargin);
                } else {
                    desireWidth = Math.max(desireWidth, v.getMeasuredWidth()
                            + lp.leftMargin + lp.rightMargin);
                    desireHeight += v.getMeasuredHeight() + lp.topMargin
                            + lp.bottomMargin;
                }
            }
        }

        //再加入viewGroup本身的padding值
        desireWidth += getPaddingLeft() + getPaddingRight();
        desireHeight += getPaddingTop() + getPaddingBottom();

        // see if the size is big enough
        desireWidth = Math.max(desireWidth, getSuggestedMinimumWidth());
        desireHeight = Math.max(desireHeight, getSuggestedMinimumHeight());

        setMeasuredDimension(resolveSize(desireWidth, widthMeasureSpec), resolveSize(desireHeight, heightMeasureSpec));
    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        final int parentLeft = getPaddingLeft();
        final int parentRight = r - l - getPaddingRight();
        final int parentTop = getPaddingTop();
        final int parentBottom = b - t - getPaddingBottom();

        if (BuildConfig.DEBUG)
            Log.d("onlayout", "parentleft: " + parentLeft + "   parenttop: " + parentTop + "   parentright: " + parentRight + "   parentbottom: " + parentBottom);

        int left = parentLeft;
        int top = parentTop;

        int count = getChildCount();
        for (int i = 0; i < count; ++i) {
            View v = getChildAt(i);
            if (v.getVisibility() != View.GONE) {
//  1.基本
//             final int childWidth = v.getMeasuredWidth();
//               final int childHeight = v.getMeasuredHeight();
//               v.layout(left, top, left + childWidth, top + childHeight);
//               left += childWidth;

// 2 .增加margin
//                LayoutParams lp = (LayoutParams) v.getLayoutParams();
//                final int childWidth = v.getMeasuredWidth();
//                final int childHeight = v.getMeasuredHeight();
//                final int gravity = lp.gravity;
//                final int horizontalGravity = gravity
//                        & Gravity.HORIZONTAL_GRAVITY_MASK;
//                final int verticalGravity = gravity
//                        & Gravity.VERTICAL_GRAVITY_MASK;
//
//                left += lp.leftMargin;
//                top = parentTop + lp.topMargin;
//                if (gravity != -1) {
//                    switch (verticalGravity) {
//                        case Gravity.TOP:
//                            break;
//                        case Gravity.CENTER_VERTICAL:
//                            top = parentTop + (parentBottom - parentTop - childHeight) / 2 + lp.topMargin - lp.bottomMargin;
//                            break;
//                        case Gravity.BOTTOM:
//                            top = parentBottom - childHeight - lp.bottomMargin;
//                            break;
//                    }
//                }
//
//                if (BuildConfig.DEBUG) {
//                    Log.d("onlayout", "child[width: " + childWidth
//                            + ", height: " + childHeight + "]");
//                    Log.d("onlayout", "child[left: " + left + ", top: "
//                            + top + ", right: " + (left + childWidth)
//                            + ", bottom: " + (top + childHeight));
//                }
//                v.layout(left, top, left + childWidth, top + childHeight);
//                left += childWidth + lp.rightMargin;

                // 3.增加方向
                LayoutParams lp = (LayoutParams) v.getLayoutParams();
                final int childWidth = v.getMeasuredWidth();
                final int childHeight = v.getMeasuredHeight();
                final int gravity = lp.gravity;
                final int orientation = lp.orientation;
                final int horizontalGravity = gravity
                        & Gravity.HORIZONTAL_GRAVITY_MASK;
                final int verticalGravity = gravity
                        & Gravity.VERTICAL_GRAVITY_MASK;

                if (orientation == HORIZONTAL) {
                    // layout horizontally, and only consider vertical gravity

                    left += lp.leftMargin;
                    top = parentTop + lp.topMargin;
                    if (gravity != -1) {
                        switch (verticalGravity) {
                            case Gravity.TOP:
                                break;
                            case Gravity.CENTER_VERTICAL:
                                top = parentTop
                                        + (parentBottom - parentTop - childHeight)
                                        / 2 + lp.topMargin - lp.bottomMargin;
                                break;
                            case Gravity.BOTTOM:
                                top = parentBottom - childHeight - lp.bottomMargin;
                                break;
                        }
                    }

                    if (BuildConfig.DEBUG) {
                        Log.d("onlayout", "child[width: " + childWidth
                                + ", height: " + childHeight + "]");
                        Log.d("onlayout", "child[left: " + left + ", top: "
                                + top + ", right: " + (left + childWidth)
                                + ", bottom: " + (top + childHeight));
                    }
                    v.layout(left, top, left + childWidth, top + childHeight);
                    left += childWidth + lp.rightMargin;
                } else {
                    // layout vertical, and only consider horizontal gravity

                    left = parentLeft;
                    top += lp.topMargin;
                    switch (horizontalGravity) {
                        case Gravity.LEFT:
                            break;
                        case Gravity.CENTER_HORIZONTAL:
                            left = parentLeft
                                    + (parentRight - parentLeft - childWidth) / 2
                                    + lp.leftMargin - lp.rightMargin;
                            break;
                        case Gravity.RIGHT:
                            left = parentRight - childWidth - lp.rightMargin;
                            break;
                    }
                    v.layout(left, top, left + childWidth, top + childHeight);
                    top += childHeight + lp.bottomMargin;
                }
            }
        }
    }



    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if(disPathEvent!=null) {
            disPathEvent.onEvent(event);
        }
        return true;
    }

    @Override
    public void computeScroll() {
        if(disPathEvent!=null) {
            disPathEvent.computeScroll();
        }
    }



    @Override
    protected android.view.ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT);
    }

    @Override
    public android.view.ViewGroup.LayoutParams generateLayoutParams(
            AttributeSet attrs) {
        return new LayoutParams(getContext(), attrs);
    }

    @Override
    protected android.view.ViewGroup.LayoutParams generateLayoutParams(
            android.view.ViewGroup.LayoutParams p) {
        return new LayoutParams(p);
    }


    /**
     * 增加gravity的支持
     */
    public static class LayoutParams extends MarginLayoutParams {
        public int gravity = -1;
        public int orientation = -1;

        public LayoutParams(Context c, AttributeSet attrs) {
            super(c, attrs);
            TypedArray ta = c.obtainStyledAttributes(attrs, R.styleable.SlideGroup);
            gravity = ta.getInt(R.styleable.SlideGroup_android_layout_gravity, -1);
            orientation = ta.getInt(R.styleable.SlideGroup_android_orientation, -1);
            ta.recycle();
        }

        public LayoutParams(int width, int height) {
            this(width, height, -1);
        }

        public LayoutParams(int width, int height, int gravity) {
            super(width, height);
            this.gravity = gravity;
        }

        public LayoutParams(android.view.ViewGroup.LayoutParams source) {
            super(source);
        }

        public LayoutParams(MarginLayoutParams source) {
            super(source);
        }
    }



    public interface disPathEvent {
        public void onEvent(MotionEvent event);
        public void computeScroll();
    }
    public void setDisPathEvent(disPathEvent listener) {
        this.disPathEvent = listener;
    }
}


